package com.peoplefirst.user.repository;

import com.peoplefirst.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    List<User> findByManagerId(UUID managerId);
    List<User> findByDepartment(String department);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
